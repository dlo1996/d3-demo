//execute script when window is loaded
window.onload = function(){
//get the <body> element from the DOM
    var container = d3.select("body")
//put a new svg in the body
      .append("svg")
      //SVG dimension variables
    var w = 900, h = 500;

     //Example 1.2 line 1...container block
    var container = d3.select("body") //get the <body> element from the DOM
        .append("svg") //put a new svg in the body
        .attr("width", w) //assign the width
        .attr("height", h) //assign the height
        .attr("class", "container") //always assign a class (as the block name) for styling and future selection
        .style("background-color", "rgba(0,0,0,0.2)");
    var innerRect = container.append("rect") //put a new rect in the svg
        .datum(400)
        .attr("width", function(d){
          return d * 2;
        }) //rectangle width
        .attr("height", function(d){
          return d;
        }) //rectangle
        attr("class", "innerRect")
        attr("x", 50)
        attr("y", 50)
        .style("fill", "#FFFFFF");
    console.log(innerRect);
};
  var minPop = d3.min(cityPOp, function(d){
    return d.population;
  });
  var maxPop = d3.max(cityPop, function(d){
    return d.population;
  });
  var y = d3.scaleLinear()
  .range([440, 95])
  .domain([
    minPop,
    maxPop
  ]);

    var color = d3.scaleLinear()
          .range([
              "#FDBE85",
              "#D94701"
          ])
          .domain([
              minPop,
              maxPop
          ]);
    var yAxis = d3.axisLeft(y);
    var axis = conatiner.append("g")
      .attr("class", "axis")
      .attr("transform", "translate(50, 0)")
      .call(yAxis);
      yAxis(axis);

    var cityPop =[
      {
      city: 'Los Angeles',
      population: 4000000
    },
    {
      city: 'Chicago',
      population: 2716000
    }
    {
      city: 'Denver',
      population: 704621
    }
    {
      city: 'New York',
      population: 8623000
    }
  ];
    var dataArray = [10, 20, 30, 40, 50];
    var circles = container.selectAll(".circles")
      .data(cityElevation)
      .enter()
      .append("circle")
      .attr("class", "circles")
      .attr("r", function(d, i){
        return d;
      })
      .attr("cx", function(d, i){
        return x(i);
      })
      .attr("cy", function(d){
        return y(d.population);
      });
      var x -d3.scaleLinear()
        .range([450,50])
        .domain([0,700000]);
      var title = container.append("text")
        .attr("class", "title")
        .attr("text-anchor", "middle")
        .attr("x", 450)
        .attr("y", 30)
        .text("City Populations");
      var labels = container.selectAll(".labels")
        .data(cityPop)
        .enter()
        .append("text")
        .attr("class", "labels")
        .attr("text-anchor", "left")
        .attr("x", function(d,i){
            return x(i) + Math.sqrt(d.population * 0.01 / Math.PI) + 5;
      })
        .attr("y", function(d){
            return y(d.population) + 5;
      })
        .text(function(d){
            return d.city + ", Pop. " + d.population;
      });
      var nameLine = labels.append("tspan")
    .attr("class", "nameLine")
    .attr("x", function(d,i){
        return x(i) + Math.sqrt(d.population * 0.01 / Math.PI) + 5;
    })
    .text(function(d){
        return d.city;
    });
var format = d3.format(",");
var popLine = labels.append("tspan")
    .attr("class", "popLine")
    .attr("x", function(d,i){
        return x(i) + Math.sqrt(d.population * 0.01 / Math.PI) + 5;
    })
    .attr("dy", "15")
    .text(function(d){
        return "Pop. " + d.population;
    });

  //Example 3.16 line 1...second line of label
